package com.auslui.androide;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View; // Add this import statement
import android.widget.Button;



public class EmptyProjectActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empty_project);

        // Assuming your "Back" button has the ID backButton
        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call finish to go back to the previous activity
                finish();
            }
        });
    }
}
